﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FlightRes.Data.Migrations
{
    public partial class inital5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
