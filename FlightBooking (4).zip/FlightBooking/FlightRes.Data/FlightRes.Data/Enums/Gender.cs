﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightRes.Data.Enums
{
    public enum Gender
    {
        male,
        female,
        other
    }
}
