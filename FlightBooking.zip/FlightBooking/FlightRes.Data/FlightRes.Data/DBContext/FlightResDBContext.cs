﻿using FlightRes.Data.Models.Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlightRes.Data.DBContext
{
    public class FlightResDBContext : DbContext
    {
        public FlightResDBContext(DbContextOptions<FlightResDBContext> options)
      : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            
        }

        public DbSet<UserDetail> UserDetails { get; set; }
    }

    
}
