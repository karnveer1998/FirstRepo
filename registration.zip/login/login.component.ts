import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import { AuthServiceService } from '../services/auth-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  LoginForm!: FormGroup;
  constructor(private authservice:AuthServiceService,private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.LoginForm = new FormGroup(
      {
        email : new FormControl('',[Validators.required,Validators.email]),
        passwordhash : new FormControl ('',[Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,}$')])

      }
  
    )
  }

  public onSubmit(_Data:any): void {

    if (this.LoginForm.invalid) {
      return;
    }   
    
    this.authservice.Login(_Data).subscribe(result =>{
      console.log("Result", result);
        this.resetForm(this.LoginForm);
      this._snackBar.open("Login Successfull...!", "Close");

      
      
            },
    err =>{
     
    console.log('error ')
         
    })
    
  }

  resetForm(RegisterForm : FormGroup)
  {
    RegisterForm.reset();
    Object.keys(RegisterForm.controls).forEach(key => {
      RegisterForm.get(key)?.setErrors(null)
    });

  }

  }