import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl,Validators,ValidatorFn,ValidationErrors, FormGroupDirective} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthServiceService } from '../services/auth-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { confirmPasswordValidator } from '../change-password/change-password.component';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  RegisterForm! : FormGroup;
  isRegister = true;
  errormessage = '';
  maxDate = new Date();


  constructor(private http : HttpClient, private authservice : AuthServiceService,private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.RegisterForm = new FormGroup(
      {
        title :new FormControl('',[Validators.required]),
        firstname :new FormControl('',[Validators.required, Validators.minLength(2),Validators.pattern('^[A-Za-z]+$')]),
        lastname :new FormControl('',[Validators.required,Validators.minLength(2),Validators.pattern('^[A-Za-z]+$')]),
        email : new FormControl('',[Validators.required,Validators.email]),
        phoneno: new FormControl('',[Validators.required,Validators.pattern('^[0-9]{1}[0-9]{9}$')]),
        gender : new FormControl('',[Validators.required]),
        useraddress :new FormControl('',[Validators.required]),
        dob :new FormControl('',[Validators.required]),
        passwordhash: new FormControl ('',[Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,}$')]),
        confirmpassword :new FormControl('',[Validators.required]),
      },

        )
    
  }
  
  Data!: any[];
  onSubmit(_Data: any) 
  {
    console.log(_Data);
    var  password = _Data.passwordhash
    var confirmpassword = _Data.confirmpassword;

    if (password === confirmpassword )
    {
      this.authservice.Register(_Data).subscribe(result =>{
        console.log("Result", result);
        this.isRegister = true;
        if(result.isActive)
        {
          this.resetForm(this.RegisterForm);
        this._snackBar.open("Registration Successfull...!", "Close");

        }
        else {
          this._snackBar.open("Email already register! Please use alternate email.", "Close");
        }
        
        
              },
      err =>{
        this.isRegister = false;
        this.errormessage = err.error.message;
        console.log(this.errormessage);
           
      })
  
    }

    else 
    {
      this._snackBar.open("Confirm Password does not match with password.", "Close");

    }
    
   //sending Data to api 
    // this.http.post('https://localhost:44368/api/UserRegistration/AddUser',_Data).subscribe((result)=> {
    //   console.log("Result",result)
    // })
  
  }


  resetForm(RegisterForm : FormGroup)
  {
    RegisterForm.reset();
    Object.keys(RegisterForm.controls).forEach(key => {
      RegisterForm.get(key)?.setErrors(null)
    });

  }
}





  
  
