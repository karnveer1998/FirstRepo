﻿using System;

namespace FlightRes.Service
{
    public class Class1
    {
    }
}
