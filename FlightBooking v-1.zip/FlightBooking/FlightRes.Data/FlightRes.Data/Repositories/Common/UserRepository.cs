﻿using FlightRes.Data.DBContext;
using FlightRes.Data.Interface;
using FlightRes.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FlightRes.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        private FlightResDBContext _context;

        public UserRepository(FlightResDBContext flightResDBContext)
        {
            _context = flightResDBContext;
        }


        public async Task<UserDetail> Register(UserDetail user)
        {
            if (user != null)
            {
                await _context.UserDetails.AddAsync(user);
                await _context.SaveChangesAsync();
                return user;
            }
            return user;
        }
    }
}
