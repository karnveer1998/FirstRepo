﻿using FlightRes.Data.DBContext;
using FlightRes.Data.Models.User;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightRes.Data.Repositories.User
{
    public class TicketRepository
    {
        private readonly FlightResDBContext _context;

        public TicketRepository(FlightResDBContext flightResDBContext)
        {
            _context = flightResDBContext;
        }
        public async Task<Ticket> GeyByPNR(int pnr)
        {
            Ticket ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.PNR == pnr);

            return  ticket;
        }
    }
}
