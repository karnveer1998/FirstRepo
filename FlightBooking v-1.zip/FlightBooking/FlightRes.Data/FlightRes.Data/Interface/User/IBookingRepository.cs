﻿using FlightRes.Data.Models.User;
using FlightRes.User.Service.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FlightRes.Data.Interface.User
{
    public interface IBookingRepository
    {
        Task<Ticket> Book(Ticket ticket);
        Task<IEnumerable<Ticket>> History(string emailid);

        Task<int> Cancel(int pnr);
    }
}
