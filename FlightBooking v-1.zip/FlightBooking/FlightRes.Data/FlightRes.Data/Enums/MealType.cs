﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightRes.Data.Enums
{
    public enum MealType
    {
        veg,
        nonveg,
        none

    }
}
