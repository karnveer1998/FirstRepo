﻿using System;

namespace FlightRes.Data
{
    public class Class1
    {
    }
}
